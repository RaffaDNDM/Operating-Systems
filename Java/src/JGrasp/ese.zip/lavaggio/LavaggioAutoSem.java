package lavaggio;
import os.*;

public class LavaggioAutoSem extends LavaggioAuto
{
    private MutexSem mx = new MutexSem();
    private Semaphore accPARZ = new Semaphore(1);
    private Semaphore accTOT = new Semaphore(1);

    public void prenotaParziale()
    {
        mx.p();

        attesaParziali++;
        stampaSituazioneLavaggio();

        /*attende se zona A piena, oppure se ho raggiunto il max per zona B*/
        if(postiALiberi == 0 || (attesaTotali > 0 && autoLavaggioT < NUM_POSTI_B)) {
            mx.v();
            accPARZ.p();//si metta in coda sul semaforo
        }

        /*quando esce occupa zona A*/
        attesaParziali--;
        postiALiberi--;
        autoLavaggioP++;
        stampaSituazioneLavaggio();

        mx.v();
    }

    public void pagaParziale()
    {
        mx.p();
        postiALiberi++;
        autoLavaggioP--;
        contaParziali++;
        stampaSituazioneLavaggio();

        /*risveglio totali se ce ne sono in attesa che possono entrare*/
        if(attesaTotali > 0 && autoLavaggioT < NUM_POSTI_B)
            accTOT.v();
        else if(attesaParziali > 0)
            accPARZ.v();
        else
            mx.v();
    }

    public void prenotaTotale()
    {
        mx.p();
        attesaTotali++;
        stampaSituazioneLavaggio();

        /*attende se zona A piena, oppure se raggiunto il max in zona B*/
        if(postiALiberi == 0 || autoLavaggioT == NUM_POSTI_B)
        {
            mx.v();
            accTOT.p();
        }

        attesaTotali--;
        postiALiberi--;
        autoLavaggioT++;
        stampaSituazioneLavaggio();

        mx.v();
    }

    public void lavaInterno()
    {
        mx.p();

        postiBLiberi--;
        postiALiberi++;
        stampaSituazioneLavaggio();

        /*usendo dalla zona A, abilita prima eventuali totali, poi eventuali parziali*/
        if(attesaTotali > 0 && autoLavaggioT < NUM_POSTI_B)
            accTOT.v();
        else if(attesaParziali > 0)
            accPARZ.v();
        else
            mx.v();
    }

    public void pagaTotale()
    {
        /*uscita dalla zona B*/
        mx.p();
        postiBLiberi++;
        autoLavaggioT--;
        contaTotali++;
        stampaSituazioneLavaggio();

        if(attesaTotali > 0 && postiALiberi > 0)
            accTOT.v();
        else
            mx.v();
    }


    public static void main(String[] args) throws InterruptedException
    {
        System.out.println("Lavaggio auto con SEMAFORI");
        LavaggioAuto lav = new LavaggioAutoSem();

        lav.stampaSituazioneLavaggio();
        for(int i = 0; i < NUM_VEICOLI;i++)
        {
            new VeicoloParziale(i, lav).start();
            Util.rsleep(250,1000);
            new VeicoloTotale(i, lav).start();
            Util.rsleep(250,1000);
        }
    }

}
