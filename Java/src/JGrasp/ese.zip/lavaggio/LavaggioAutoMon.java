package lavaggio;
import os.*;

public class LavaggioAutoMon extends LavaggioAuto
{
    /*si può estendere solo una classe, quindi non potendo estendere anche monitor
    * ne viene dichiarata una variabile e i necessari condition*/
    private Monitor lavaggio = new Monitor();
    private Monitor.Condition parziali =  lavaggio.new Condition();
    private Monitor.Condition totali =  lavaggio.new Condition();

    public void prenotaParziale()
    {
        lavaggio.mEnter();
        attesaParziali++;
        stampaSituazioneLavaggio();

        /*attende se zona A piena, oppure se ho dei totali in attesa e non sono al massimo della capienza*/
        if(postiALiberi == 0 || (attesaTotali > 0 && autoLavaggioT < NUM_POSTI_B))
            parziali.cWait();

        /*quando esce occupa zona A*/
        attesaParziali--;
        postiALiberi--;
        autoLavaggioP++;
        stampaSituazioneLavaggio();

        lavaggio.mExit();
    }

    public void pagaParziale()
    {
        lavaggio.mEnter();
        postiALiberi++;
        autoLavaggioP--;
        contaParziali++;
        stampaSituazioneLavaggio();

        /*risveglio totali se ce ne sono in attesa che possono entrare*/
        if(attesaTotali > 0 && autoLavaggioT < NUM_POSTI_B)
            totali.cSignal();
        else if(attesaParziali > 0)
            parziali.cSignal();

        lavaggio.mExit();
    }

    public void prenotaTotale()
    {
        lavaggio.mEnter();
        attesaTotali++;
        stampaSituazioneLavaggio();

        /*attende se zona A piena, oppure se raggiunto il max in zona B*/
        if(postiALiberi == 0 || autoLavaggioT == NUM_POSTI_B)
            totali.cWait();

        attesaTotali--;
        postiALiberi--;
        autoLavaggioT++;
        stampaSituazioneLavaggio();

        lavaggio.mExit();
    }

    public void lavaInterno()
    {
        /*lascio zona A ed entro in B*/
        lavaggio.mEnter();
        postiBLiberi--;
        postiALiberi++;
        stampaSituazioneLavaggio();

        /*usendo dalla zona A, abilita prima eventuali totali, poi eventuali parziali*/
        if(attesaTotali > 0 && autoLavaggioT < NUM_POSTI_B)
            totali.cSignal();
        else if(attesaParziali > 0)
            parziali.cSignal();

        lavaggio.mExit();
    }

    public void pagaTotale()
    {
        /*uscita dalla zona B*/
        lavaggio.mEnter();
        postiBLiberi++;
        autoLavaggioT--;
        contaTotali++;
        stampaSituazioneLavaggio();

        if(attesaTotali > 0 && postiALiberi > 0)
            totali.cSignal();

        lavaggio.mExit();
    }


    public static void main(String[] args) throws InterruptedException
    {
        System.out.println("Lavaggio auto con MONITOR DI HOARE");
        LavaggioAuto lav = new LavaggioAutoMon();

        lav.stampaSituazioneLavaggio();
        for(int i = 0; i < NUM_VEICOLI;i++)
        {
            new VeicoloParziale(i, lav).start();
            Util.rsleep(250,1000);
            new VeicoloTotale(i, lav).start();
            Util.rsleep(250,1000);
        }
    }

}
