package lavaggio;
import os.*;

public class VeicoloTotale extends Thread
{
    private int io;
    private LavaggioAuto la;

    public VeicoloTotale(int io, LavaggioAuto la)
    {
        this.io = io;
        this.la = la;
    }

    public void run()
    {
        Util.rsleep(1000,3000);
        System.out.println("--Veicolo totale T " + io + " prenota zona A");
        la.prenotaTotale();
        System.out.println("--Veicolo totale T " + io + " entra in zona A");
        Util.rsleep(8000);
        System.out.println("--Veicolo totale T " + io + " passa al lavaggio interno");
        la.lavaInterno();
        System.out.println("--Veicolo totale T " + io + " entra in zona B");
        Util.rsleep(6000);
        System.out.println("--Veicolo totale T " + io + " paga ed esce");
        la.pagaTotale();
    }
}
