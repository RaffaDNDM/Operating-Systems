package lavaggio;
import os.*;

public class VeicoloParziale extends Thread
{
    private int io;
    private LavaggioAuto la;

    public VeicoloParziale(int io, LavaggioAuto la)
    {
        this.io = io;
        this.la = la;
    }

    public void run()
    {
        Util.rsleep(500,2000);
        System.out.println("--Veicolo parziale P " + io + "prenota zona A");
        la.prenotaParziale();
        System.out.println("--Veicolo parziale P " + io + "entra in zona A");
        Util.rsleep(8000);
        System.out.println("--Veicolo parziale P " + io + "paga ed esce");
        la.pagaParziale();
    }
}
