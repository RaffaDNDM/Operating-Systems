package lavaggio;
import os.*;


public abstract class LavaggioAuto
{
    public static final int NUM_VEICOLI = 20;/*considero al massimo questi veicoli*/
    /*posti di lavaggio*/
    public static final int NUM_POSTI_A = 8;
    public static final int NUM_POSTI_B = 4;

    /*variabili comuni*/
    /*auto in lavaggio parziale*/
    protected int autoLavaggioP = 0;
    /*auto in lavaggio totale*/
    protected int autoLavaggioT = 0;
    /*posti liberi*/
    protected int postiALiberi = NUM_POSTI_A;
    protected int postiBLiberi = NUM_POSTI_B;
    /*code attesa*/
    protected int attesaParziali = 0;
    protected int attesaTotali = 0;
    /*conteggio lavaggi*/
    protected int contaParziali = 0;
    protected int contaTotali = 0;

    protected void stampaSituazioneLavaggio()
    {
        System.out.println("---LAVAGGIO: Parziali= " + autoLavaggioP+ " Totali = " + autoLavaggioT);

        System.out.println("Situazione zona A:");
        for(int p = 0 ; p< NUM_POSTI_A; p++)
            if(p < NUM_POSTI_A - postiALiberi)
                System.out.println("X");
            else
                System.out.println("O");

        System.out.println("");

        System.out.println("Situazione zona B:");
        for(int p = 0 ; p< NUM_POSTI_B; p++)
            if(p < NUM_POSTI_B - postiBLiberi)
                System.out.println("X");
            else
                System.out.println("O");

        System.out.println("");

        System.out.println("Situazione zona di PRENOTAZIONE:\n-");
        for(int e = 0 ; e< attesaTotali; e++)
            System.out.println("T");

        System.out.println("\n-");

        System.out.println("Situazione zona di PRENOTAZIONE:\n-");
        for(int e = 0 ; e< attesaParziali; e++)
            System.out.println("P");

        System.out.println("\n-");

        System.out.println("---LAVATI: Parziali= " + contaParziali+ " Totali = " + contaTotali);
    }

    public abstract void prenotaParziale();
    public abstract void prenotaTotale();
    public abstract void pagaParziale();
    public abstract void pagaTotale();
    public abstract void lavaInterno();
}
