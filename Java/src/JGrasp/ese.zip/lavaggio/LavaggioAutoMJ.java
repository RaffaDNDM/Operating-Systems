package lavaggio;
import os.*;

public class LavaggioAutoMJ extends LavaggioAuto
{
    private int nextTicketParz = 0;
    private int nextTicketTot = 0;

    public synchronized void prenotaParziale()
    {
        attesaParziali++;
        stampaSituazioneLavaggio();

        /*attende se zona A piena, oppure se ho raggiunto il max per zona B*/
        while(postiALiberi == 0 || (attesaTotali > 0 && autoLavaggioT < NUM_POSTI_B)) {
            try {
                wait();
            } catch (InterruptedException e) { }
        }

        /*quando esce occupa zona A*/
        attesaParziali--;
        postiALiberi--;
        autoLavaggioP++;
        stampaSituazioneLavaggio();

    }

    public synchronized void pagaParziale()
    {
        postiALiberi++;
        autoLavaggioP--;
        contaParziali++;
        stampaSituazioneLavaggio();

        /*risveglio totali se ce ne sono in attesa che possono entrare*/
        /*if(attesaTotali > 0 && autoLavaggioT < NUM_POSTI_B)
            accTOT.v();
        else if(attesaParziali > 0)
            accPARZ.v();
        else
            mx.v();*/
        notifyAll();
    }

    public synchronized void prenotaTotale()
    {
        mx.p();
        attesaTotali++;
        stampaSituazioneLavaggio();

        /*attende se zona A piena, oppure se raggiunto il max in zona B*/
        if(postiALiberi == 0 || autoLavaggioT == NUM_POSTI_B)
        {
            mx.v();
            accTOT.p();
        }

        attesaTotali--;
        postiALiberi--;
        autoLavaggioT++;
        stampaSituazioneLavaggio();

        mx.v();
    }

    public synchronized void lavaInterno()
    {
        postiBLiberi--;
        postiALiberi++;
        stampaSituazioneLavaggio();

        /*usendo dalla zona A, abilita prima eventuali totali, poi eventuali parziali*/
        /*if(attesaTotali > 0 && autoLavaggioT < NUM_POSTI_B)
            accTOT.v();
        else if(attesaParziali > 0)
            accPARZ.v();
        else
            mx.v();*/
        notifyAll();
    }

    public synchronized void pagaTotale()
    {
        /*uscita dalla zona B*/
        postiBLiberi++;
        autoLavaggioT--;
        contaTotali++;
        stampaSituazioneLavaggio();

        /*if(attesaTotali > 0 && postiALiberi > 0)
            accTOT.v();
        else
            mx.v();*/
        notifyAll();
    }


    public static void main(String[] args) throws InterruptedException
    {
        System.out.println("Lavaggio auto con SEMAFORI");
        LavaggioAuto lav = new LavaggioAutoMJ();

        lav.stampaSituazioneLavaggio();
        for(int i = 0; i < NUM_VEICOLI;i++)
        {
            new VeicoloParziale(i, lav).start();
            Util.rsleep(250,1000);
            new VeicoloTotale(i, lav).start();
            Util.rsleep(250,1000);
        }
    }

}
