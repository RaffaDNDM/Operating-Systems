import os.ada.*;

/**{c}
 * Fontebella, esempio per prima prova intermedia - 
 * soluzione con ADA-Java
 * server
 * @author M.Moro DEI UNIPD
 * @version 1.00 2012-04-05
 */
 
public class FontanaADAAll extends ADAThread implements FontanaADAAllStr
{

    private static final long SERVTMO = 2000L;
      // timeout vari
    private static final long RIEMPIMENTO = 15500L;
      // tempo di riempimento
    private int clientiA = 0, clientiB = 0;
      // clienti nelle rispettive code
    private int stat = 2;
      // conteggio per priorita` clienti B
    private int zampilliLiberi = 8;
      // i clienti in fontana saranno 8-zampilliLiberi
    private int ultimoZampillo = 7;
      // ultimo zampillo occupato (0..7)

    /**[c]
     * thread server allocatore Fontebella,
     * @param name  nome del thread
     */
    public FontanaADAAll(String name)
    {
        super(name);
    } //[c]

    /**[m]
     * allocatore Fontebella
     */
    public void run()
    {
        // select unico
        Select sel = new Select();

/* esempio d'uso della MACRO semplificativa:
        ENTRYCOUNT TORNA LE RICHIESTE PENDENTI SULLA COSA
        ricorda che la guardia è di apertura, quindi qui va negato
        sel.add( when (zampilliLiberi>0 && (entryCount(codaBStr)==0 
          || stat==0) => 
          codaA[out: int zamp]
          {
            // parametro di input non significativo
            zampilliLiberi--;
            // reset di stat
            stat=2;
            System.out.println("************ zampilli liberi = "+zampilliLiberi);
            // assegna zampillo
            zamp = (ultimoZampillo = (ultimoZampillo+1)%8)+1;
          }
          );
*/        
        // entry codaA, choice=0
        sel.add(new Guard()
          {
            public boolean when()
            {
                return zampilliLiberi>0 && (entryCount(codaBStr)==0 
                  || stat==0);
            } //[m] when
          } //{c} <anonim>
          , codaAStr,//nome entry
          new Entry()
          {
            public Object exec(Object inp)
            {
                // parametro di input non significativo
                zampilliLiberi--;
                // reset di stat
                stat=2;
                System.out.println("************ zampilli liberi = "+zampilliLiberi);
                // assegna zampillo
                int zamp = (ultimoZampillo = (ultimoZampillo+1)%8)+1;
                return new Integer(zamp);
            }
          } //{c} <anonim>
          );

        // entry codaB, choice=1
        sel.add(new Guard()
          {
            public boolean when()
            {
                return zampilliLiberi!=0 && 
                  (entryCount(codaAStr)==0 || stat!=0);
            } //[m] when
          } //{c} <anonim>
          , codaBStr,
          new Entry()
          {
            public Object exec(Object inp)
            {
                zampilliLiberi--;
                System.out.println("************ zampilli liberi = "+zampilliLiberi);
                if (entryCount(codaAStr)>0)
                    stat--;  // conteggio specifico
                // assegna zampillo
                int zamp = (ultimoZampillo = (ultimoZampillo+1)%8)+1;
                return new Integer(zamp);
            }
          } //{c} <anonim>
          );

        // entry uscita, choice=2, nessuna guardia ossia sempre disponibile
        sel.add(uscitaStr,
          new Entry()
          {
            public Object exec(Object inp)
            {
                zampilliLiberi++;
                  // uno zampillo liberato
                System.out.println("************ zampilli liberi = "+zampilliLiberi);
                return null;
            }
          } //{c} <anonim>
          );

        // entry stato, choice= CON TIMEOUT
        sel.add(new Guard()
          {
            public boolean when()
            {
                return zampilliLiberi<=1;
            } //[m] when
          } //{c} <anonim>
          , SERVTMO  // delay costante
        );

        while (true)
        {
            //SE SCELGO L'ULTIMO CASO
            //SIMULO CON CHOICE IL CASO ELSE
            int choice = sel.accept();
            System.out.println("[[[entry "+sel.choice2Str(choice));
            switch(choice)
            {
              case 3:
                System.out.println("[[!!!! SERVER TIMEOUT zampilli liberi="+zampilliLiberi);
                break;
              default:
                // nulla
            }
        }
    } //[m] run

} //{c} FontanaADAAll
