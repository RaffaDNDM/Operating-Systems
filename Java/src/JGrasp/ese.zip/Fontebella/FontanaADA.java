import os.ada.*;
import os.Util;
 
/**{c}
 * Fontebella, esempio per prima prova intermedia - 
 * soluzione con ADA-Java
 * programma principale
 * @author M.Moro DEI UNIPD
 * @version 1.00 2012-04-05
 */
 
public class FontanaADA implements FontanaADAAllStr
{
    private static final long RIEMPIMENTO = 15500L;
      // tempo di riempimento

    /**{c}
     * thread clienti di tipo A
     */
    private class ClienteATh extends ADAThread
    {
        /**[c]
         * @param name  nome del cliente
         */
        public ClienteATh(String name)
        {
            super(name);
        }
        
        /**[m]
         * test: sequenza per un cliente A
         */
        public void run()
        {
            System.out.println("!!! Il cliente "+getName()+" di tipo A va in coda");
            CallOut rep = entryCall(null, fontAllStr, codaAStr);
                  // chiamata di RV
            int zamp= ((Integer)rep.getParams()).intValue();
            System.out.println("+++ Il cliente "+getName()+
              " di tipo A va a bere allo zampillo "+zamp);
            Util.sleep(RIEMPIMENTO);
              // beve
            System.out.println("--- Il cliente "+getName()+
              " di tipo A lascia lo zampillo "+zamp);
            rep = entryCall(null, fontAllStr, uscitaStr);
              // lascia la fontana  
        } //[m] run
                    
    } // {c} ClienteATh
        
    /**{c}
     * thread clienti di tipo B
     */
    private class ClienteBTh extends ADAThread
    {
        /**[c]
         * @param name  nome del cliente
         */
        public ClienteBTh(String name)
        {
            super(name);
        }
        
        /**[m]
         * test: sequenza per un cliente B
         */
        public void run()
        {
            System.out.println("!!! Il cliente "+getName()+" di tipo B va in coda");
            CallOut rep = entryCall(null, fontAllStr, codaBStr);
                  // chiamata di RV
            int zamp= ((Integer)rep.getParams()).intValue();
            System.out.println("+++ Il cliente "+getName()+
              " di tipo B va a bere allo zampillo "+zamp);
            Util.sleep(RIEMPIMENTO);
              // beve
            System.out.println("--- Il cliente "+getName()+
              " di tipo B lascia lo zampillo "+zamp);
            rep = entryCall(null, fontAllStr, uscitaStr);
              // lascia la fontana  
        } //[m] run
                    
    } // {c} ClienteBTh
        
    /**[m][s]
     * main di collaudo
     */
    public static void main(String[] args) 
    {
        System.err.println("** Battere Ctrl-C per terminare!");
        FontanaADA fo = new FontanaADA();
        new FontanaADAAll(fontAllStr).start();
        int cnt=1;
        for(;;)
        {
            Util.rsleep(500, 2000);
            if (Util.randVal(1,2) == 1)
                fo.new ClienteATh("num"+(cnt++)).start();
            else
                fo.new ClienteBTh("num"+(cnt++)).start();
        }
    } //[m][s] main
    
} //{c} FontanaADA
