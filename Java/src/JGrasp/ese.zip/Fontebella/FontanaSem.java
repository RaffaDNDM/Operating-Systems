import os.Semaphore; 
import os.Util; 
 
/**{c}
 * Fontebella, esempio per prima prova intermedia - 
 * soluzione con semafori privati
 * @author M.Moro DEI UNIPD
 * @version 1.00 2005-10-28
 */
 
public class FontanaSem
{
    private static final long RIEMPIMENTO = 15500L;
      // tempo di riempimento
    // il conteggio dei clienti in coda e` sostituito
    // dal contatore del relativo semaforo
    private int stat = 2;
      // conteggio per priorita` clienti B
    private int zampilliLiberi = 8;
      // i clienti in fontana saranno 8-zampilliLiberi
    private int ultimoZampillo = 7;
      // ultimo zampillo occupato (0..7)
    private Semaphore mutex = new Semaphore(true);
      // protezione della sezione critica
    private Semaphore attesaA = new Semaphore(false);
    private Semaphore attesaB = new Semaphore(false);
      // semafori privati dei clienti in attesa
      
    /**{c}
     * thread clienti di tipo A
     */
    private class ClienteATh extends Thread
    {
        /**[c]
         * @param name  nome del cliente
         */
        public ClienteATh(String name)
        {
            super(name);
        }
        
        /**[m]
         * test: sequenza per un cliente A
         */
        public void run()
        {
            System.out.println("!!! Il cliente "+getName()+" di tipo A va in coda");
            int zamp=entraCodaA();
            System.out.println("+++ Il cliente "+getName()+
              " di tipo A va a bere allo zampillo "+zamp);
            Util.sleep(RIEMPIMENTO);
              // beve
            System.out.println("--- Il cliente "+getName()+
              " di tipo A lascia lo zampillo "+zamp);
            fineRiempimento();
              // lascia la fontana  
        } //[m] run
                    
    } // {c} ClienteATh
        
    /**{c}
     * thread clienti di tipo B
     */
    private class ClienteBTh extends Thread
    {
        /**[c]
         * @param name  nome del cliente
         */
        public ClienteBTh(String name)
        {
            super(name);
        }
        
        /**[m]
         * test: sequenza per un cliente B
         */
        public void run()
        {
            System.out.println("!!! Il cliente "+getName()+" di tipo B va in coda");
            int zamp=entraCodaB();
            System.out.println("+++ Il cliente "+getName()+
              " di tipo B va a bere allo zampillo "+zamp);
            Util.sleep(RIEMPIMENTO);
              // beve
            System.out.println("--- Il cliente "+getName()+
              " di tipo B lascia lo zampillo "+zamp);
            fineRiempimento();
              // lascia la fontana  
        } //[m] run
                    
    } // {c} ClienteBTh
        
    /**[m]
     * ingresso in coda A
     * @return lo zampillo assegnato
     */
    public int entraCodaA()
    {
        mutex.p();
        // verifica la condizione di attesa sul semaforo privato tipo A
        /*se ci sono già clientiA in attesa, oppure se non ci sono zampilli liberi, oppure
        * se ho dei clientiB in atessa con uno stato non zero*/
        /*allora attendo*/
        if (attesaA.queue()>0 || zampilliLiberi==0 || 
          (attesaB.queue()>0 && stat!=0))
        {
            // deve attendere
            System.out.println("vvv Il cliente "+Thread.currentThread().getName()+
              " di tipo A attende in coda (clientiA="+attesaA.queue()+")");
            mutex.v();
            //attendo che qualche clienteA faccia il fineRiempimento
            attesaA.p();
            // risvegliato in mutua esclusione
            System.out.println("^^^ Il cliente "+Thread.currentThread().getName()+
              " di tipo A termina l'attesa in coda (clientiA="+attesaA.queue()+")");
        }
        // assegna zampillo in mutua esclusione
        zampilliLiberi--;
        // reset di stato perchè ho appena fatto iniziare il servizio ad un clientA
        stat=2;
        System.out.println("************ zampilli liberi = "+zampilliLiberi);
        int zamp = (ultimoZampillo = (ultimoZampillo+1)%8)+1;
        mutex.v();
        return zamp;
    } //[m] entraCodaA
    
    /**[m]
     * ingresso in coda B
     * @return lo zampillo assegnato
     */
    public int entraCodaB()
    {
        mutex.p();
        // verifica la condizione di attesa sul semaforo privato tipo B
        if (attesaB.queue()>0 || zampilliLiberi==0 || 
          (attesaA.queue()>0 && stat==0))
        {
            // deve attendere
            System.out.println("vvv Il cliente "+Thread.currentThread().getName()+
              " di tipo B attende in coda (clientiB="+attesaB.queue()+")");
            mutex.v();
            attesaB.p();
            // risvegliato in mutua esclusione
            System.out.println("^^^ Il cliente "+Thread.currentThread().getName()+
              " di tipo B termina l'attesa in coda (clientiB="+attesaB.queue()+")");
        }
        // assegna zampillo in mutua esclusione
        zampilliLiberi--;
        System.out.println("************ zampilli liberi = "+zampilliLiberi);
        if (attesaA.queue()>0)
            stat--;  // conteggio specifico
        int zamp = (ultimoZampillo = (ultimoZampillo+1)%8)+1;
        mutex.v();
        return zamp;
    } //[m] entraCodaB
    
    /**[m]
     * lascia la fontana
     */
    public void fineRiempimento()
    {
        mutex.p();
        zampilliLiberi++;
          // uno zampillo liberato
        System.out.println("************ zampilli liberi = "+zampilliLiberi);
        // valuta condizione per il rilascio di un cliente B
        // che ha priorita`
        if (attesaB.queue()>0 && (attesaA.queue()==0 || stat!=0))
            // cede al cliente risvegliato la mutua esclusione
            attesaB.v();
        // valuta condizione per il rilascio di un cliente A
        else if (attesaA.queue()>0)
            // cede al cliente risvegliato la mutua esclusione
            attesaA.v();
        else
            // solo in questo caso rilascia la mutua esclusione
            mutex.v();
    } //[m] fineRiempimento

    /**[m][s]
     * main di collaudo
     */
    public static void main(String[] args) 
    {
        System.err.println("** Battere Ctrl-C per terminare!");
        FontanaSem fo = new FontanaSem();
        int cnt=1;
        for(;;)
        {
            Util.rsleep(500, 2000);
            if (Util.randVal(1,2) == 1)
                fo.new ClienteATh("num"+(cnt++)).start();
            else
                fo.new ClienteBTh("num"+(cnt++)).start();
        }
    } //[m][s] main
    
} //{c} FontanaSem

