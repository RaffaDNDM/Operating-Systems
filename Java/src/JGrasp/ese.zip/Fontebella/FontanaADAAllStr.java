/**{c}
 * Fontebella, esempio per prima prova intermedia - 
 * soluzione con ADA-Java
 * stringhe di supporto
 * @author M.Moro DEI UNIPD
 * @version 1.00 2012-04-05
 */

//interfaccia
public interface FontanaADAAllStr
{
    //nome del server
    static final String fontAllStr = "fontall";
      // nome del server
    //nomi dei servizi del serve
    static final String codaAStr = "codaA";
    static final String codaBStr = "codaB";
    static final String uscitaStr = "uscita";
      // nome dei selettori

} //{c} FontanaADAAllStr

