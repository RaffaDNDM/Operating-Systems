import os.Util; 
 
/**{c}
 * Fontebella, esempio per prima prova intermedia - 
 * soluzione con Monitor di Java e ticket
 * @author M.Moro DEI UNIPD
 * @version 1.00 2005-10-28
 */
 
public class FontanaJav
{
    private static final long RIEMPIMENTO = 15500L;
      // tempo di riempimento
    private int clientiA = 0, clientiB = 0;
      // clienti nelle rispettive code
    private int stat = 2;
      // conteggio per priorita` clienti B
    private int zampilliLiberi = 8;
      // i clienti in fontana saranno 8-zampilliLiberi
    private int ultimoZampillo = 7;
      // ultimo zampillo occupato (0..7)
    private int ticketA=0, ticketB=0;
    private int servizioA=0, servizioB=0;
      // per assicurare l'ordine
      
    /**{c}
     * thread clienti di tipo A
     */
    private class ClienteATh extends Thread
    {
        /**[c]
         * @param name  nome del cliente
         */
        public ClienteATh(String name)
        {
            super(name);
        }
        
        /**[m]
         * test: sequenza per un cliente A
         */
        public void run()
        {
            System.out.println("!!! Il cliente "+getName()+" di tipo A va in coda");
            int zamp=entraCodaA();
            System.out.println("+++ Il cliente "+getName()+
              " di tipo A va a bere allo zampillo "+zamp);
            Util.sleep(RIEMPIMENTO);
              // beve
            System.out.println("--- Il cliente "+getName()+
              " di tipo A lascia lo zampillo "+zamp);
            fineRiempimento();
              // lascia la fontana  
        } //[m] run
                    
    } // {c} ClienteATh
        
    /**{c}
     * thread clienti di tipo B
     */
    private class ClienteBTh extends Thread
    {
        /**[c]
         * @param name  nome del cliente
         */
        public ClienteBTh(String name)
        {
            super(name);
        }
        
        /**[m]
         * test: sequenza per un cliente B
         */
        public void run()
        {
            System.out.println("!!! Il cliente "+getName()+" di tipo B va in coda");
            int zamp=entraCodaB();
            System.out.println("+++ Il cliente "+getName()+
              " di tipo B va a bere allo zampillo "+zamp);
            Util.sleep(RIEMPIMENTO);
              // beve
            System.out.println("--- Il cliente "+getName()+
              " di tipo B lascia lo zampillo "+zamp);
            fineRiempimento();
              // lascia la fontana  
        } //[m] run
                    
    } // {c} ClienteBTh
        
    /**[m]
     * ingresso in coda A
     * @return lo zampillo assegnato
     */
    public synchronized int entraCodaA()
    {
        clientiA++;
        System.out.println("vvv Il cliente "+Thread.currentThread().getName()+
          " di tipo A attende in coda (clientiA="+clientiA+")");
        int ticket = ticketA++;
        // ripete l'attesa su condizione
        while(zampilliLiberi==0 || (clientiB>0 && stat!=0) || servizioA != ticket)
            try { wait(); } catch (InterruptedException e) {};
        clientiA--;
        System.out.println("^^^ Il cliente "+Thread.currentThread().getName()+
          " di tipo A termina l'attesa in coda (clientiA="+clientiA+")");
        // assegna zampillo
        zampilliLiberi--;
        // reset di stat
        stat=2;
        System.out.println("************ zampilli liberi = "+zampilliLiberi);
        servizioA++;
        return (ultimoZampillo = (ultimoZampillo+1)%8)+1;
    } //[m] entraCodaA
    
    /**[m]
     * ingresso in coda B
     * @return lo zampillo assegnato
     */
    public synchronized int entraCodaB()
    {
        clientiB++;
        System.out.println("vvv Il cliente "+Thread.currentThread().getName()+
          " di tipo B attende in coda (clientiB="+clientiB+")");
        int ticket = ticketB++;
        // ripete l'attesa su condizione
        while(zampilliLiberi==0 || (clientiA>0 && stat==0) || servizioB != ticket)
            try { wait(); } catch (InterruptedException e) {};
        clientiB--;
        System.out.println("^^^ Il cliente "+Thread.currentThread().getName()+
          " di tipo B termina l'attesa in coda (clientiB="+clientiB+")");
        // assegna zampillo
        zampilliLiberi--;
        System.out.println("************ zampilli liberi = "+zampilliLiberi);
        if (clientiA>0)
            stat--;  // conteggio specifico
        servizioB++;
        return (ultimoZampillo = (ultimoZampillo+1)%8)+1;
    } //[m] entraCodaB
    
    /**[m]
     * lascia la fontana
     */
    public synchronized void fineRiempimento()
    {
        zampilliLiberi++;
          // uno zampillo liberato
        System.out.println("************ zampilli liberi = "+zampilliLiberi);
        notifyAll();
    } //[m] fineRiempimento

    /**[m][s]
     * main di collaudo
     */
    public static void main(String[] args) 
    {
        System.err.println("** Battere Ctrl-C per terminare!");
        FontanaJav fo = new FontanaJav();
        int cnt=1;
        for(;;)
        {
            Util.rsleep(500, 2000);
            if (Util.randVal(1,2) == 1)
                fo.new ClienteATh("num"+(cnt++)).start();
            else
                fo.new ClienteBTh("num"+(cnt++)).start();
        }
    } //[m][s] main
    
} //{c} FontanaJav

