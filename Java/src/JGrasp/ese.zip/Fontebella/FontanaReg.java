import os.Region; 
import os.RegionCondition; 
import os.Util; 
 
/**{c}
 * Fontebella, esempio per prima prova intermedia - 
 * soluzione con Regione critica
 * @author M.Moro DEI UNIPD
 * @version 1.00 2005-10-28
 */
 
public class FontanaReg
{
    private static final long RIEMPIMENTO = 15500L;
      // tempo di riempimento
    private int clientiA = 0, clientiB = 0;
      // clienti nelle rispettive code
    private int stat = 2;
      // conteggio per priorita` clienti B
    private int zampilliLiberi = 8;
      // i clienti in fontana saranno 8-zampilliLiberi
    private int ultimoZampillo = 7;
      // ultimo zampillo occupato (0..7)
    private Region ass = new Region(0);
      // protezione della sezione critica
      
    /**{c}
     * thread clienti di tipo A
     */
    private class ClienteATh extends Thread
    {
        /**[c]
         * @param name  nome del cliente
         */
        public ClienteATh(String name)
        {
            super(name);
        }
        
        /**[m]
         * test: sequenza per un cliente A
         */
        public void run()
        {
            System.out.println("!!! Il cliente "+getName()+" di tipo A va in coda");
            int zamp=entraCodaA();
            System.out.println("+++ Il cliente "+getName()+
              " di tipo A va a bere allo zampillo "+zamp);
            Util.sleep(RIEMPIMENTO);
              // beve
            System.out.println("--- Il cliente "+getName()+
              " di tipo A lascia lo zampillo "+zamp);
            fineRiempimento();
              // lascia la fontana  
        } //[m] run
                    
    } // {c} ClienteATh
        
    /**{c}
     * thread clienti di tipo B
     */
    private class ClienteBTh extends Thread
    {
        /**[c]
         * @param name  nome del cliente
         */
        public ClienteBTh(String name)
        {
            super(name);
        }
        
        /**[m]
         * test: sequenza per un cliente B
         */
        public void run()
        {
            System.out.println("!!! Il cliente "+getName()+" di tipo B va in coda");
            int zamp=entraCodaB();
            System.out.println("+++ Il cliente "+getName()+
              " di tipo B va a bere allo zampillo "+zamp);
            Util.sleep(RIEMPIMENTO);
              // beve
            System.out.println("--- Il cliente "+getName()+
              " di tipo B lascia lo zampillo "+zamp);
            fineRiempimento();
              // lascia la fontana  
        } //[m] run
                    
    } // {c} ClienteBTh
        
    /**[m]
     * ingresso in coda A
     * @return lo zampillo assegnato
     */
    public int entraCodaA()
    {
        ass.enterWhen();
        // prenotazione
        clientiA++;
        System.out.println("vvv Il cliente "+Thread.currentThread().getName()+
          " di tipo A attende in coda (clientiA="+clientiA+")");
        ass.leave();
        ass.enterWhen(new RegionCondition() {
            public boolean evaluate()
            {
                // verifica la condizione di risveglio di A
                return !(zampilliLiberi==0 || (clientiB>0 && stat!=0));
            }
        });
        clientiA--;
        System.out.println("^^^ Il cliente "+Thread.currentThread().getName()+
          " di tipo A termina l'attesa in coda (clientiA="+clientiA+")");
        // assegna zampillo
        zampilliLiberi--;
        // reset di stat
        stat=2;
        System.out.println("************ zampilli liberi = "+zampilliLiberi);
        int zamp = (ultimoZampillo = (ultimoZampillo+1)%8)+1;
        ass.leave();
        return zamp;
    } //[m] entraCodaA
    
    /**[m]
     * ingresso in coda B
     * @return lo zampillo assegnato
     */
    public int entraCodaB()
    {
        ass.enterWhen();
        // prenotazione
        clientiB++;
        System.out.println("vvv Il cliente "+Thread.currentThread().getName()+
          " di tipo B attende in coda (clientiB="+clientiB+")");
        ass.leave();
        ass.enterWhen(new RegionCondition() {
            public boolean evaluate()
            {
                // verifica la condizione di risveglio di B
                return !(zampilliLiberi==0 || (clientiA>0 && stat==0));
            }
        });
        clientiB--;
        System.out.println("^^^ Il cliente "+Thread.currentThread().getName()+
          " di tipo B termina l'attesa in coda (clientiB="+clientiB+")");
        // assegna zampillo
        zampilliLiberi--;
        System.out.println("************ zampilli liberi = "+zampilliLiberi);
        if (clientiA>0)
            stat--;  // conteggio specifico
        int zamp = (ultimoZampillo = (ultimoZampillo+1)%8)+1;
        ass.leave();
        return zamp;
    } //[m] entraCodaB
    
    /**[m]
     * lascia la fontana
     */
    public void fineRiempimento()
    {
        ass.enterWhen();
        zampilliLiberi++;
          // uno zampillo liberato
        System.out.println("************ zampilli liberi = "+zampilliLiberi);
        ass.leave();
    } //[m] fineRiempimento

    /**[m][s]
     * main di collaudo
     */
    public static void main(String[] args) 
    {
        System.err.println("** Battere Ctrl-C per terminare!");
        FontanaReg fo = new FontanaReg();
        int cnt=1;
        for(;;)
        {
            Util.rsleep(500, 2000);
            if (Util.randVal(1,2) == 1)
                fo.new ClienteATh("num"+(cnt++)).start();
            else
                fo.new ClienteBTh("num"+(cnt++)).start();
        }
    } //[m][s] main
    
} //{c} FontanaReg

