import os.Monitor; 
import os.Util; 
 
/**{c}
 * Fontebella, esempio per prima prova intermedia - 
 * soluzione con Monitor di Hoare
 * @author M.Moro DEI UNIPD
 * @version 1.00 2005-10-28
 */
 
public class FontanaMon extends Monitor
{
    private static final long RIEMPIMENTO = 15500L;
      // tempo di riempimento
    private int clientiA = 0, clientiB = 0;
      // clienti nelle rispettive code
    private int stat = 2;
      // conteggio per priorita` clienti B
    private int zampilliLiberi = 8;
      // i clienti in fontana saranno 8-zampilliLiberi
    private int ultimoZampillo = 7;
      // ultimo zampillo occupato (0..7)
    private Condition attesaA = new Condition();
    private Condition attesaB = new Condition();
      // clienti in attesa
      
    /**{c}
     * thread clienti di tipo A
     */
    private class ClienteATh extends Thread
    {
        /**[c]
         * @param name  nome del cliente
         */
        public ClienteATh(String name)
        {
            super(name);
        }
        
        /**[m]
         * test: sequenza per un cliente A
         */
        public void run()
        {
            System.out.println("!!! Il cliente "+getName()+" di tipo A va in coda");
            int zamp=entraCodaA();
            System.out.println("+++ Il cliente "+getName()+
              " di tipo A va a bere allo zampillo "+zamp);
            Util.sleep(RIEMPIMENTO);
              // beve
            System.out.println("--- Il cliente "+getName()+
              " di tipo A lascia lo zampillo "+zamp);
            fineRiempimento();
              // lascia la fontana  
        } //[m] run
                    
    } // {c} ClienteATh
        
    /**{c}
     * thread clienti di tipo B
     */
    private class ClienteBTh extends Thread
    {
        /**[c]
         * @param name  nome del cliente
         */
        public ClienteBTh(String name)
        {
            super(name);
        }
        
        /**[m]
         * test: sequenza per un cliente B
         */
        public void run()
        {
            System.out.println("!!! Il cliente "+getName()+" di tipo B va in coda");
            int zamp=entraCodaB();
            System.out.println("+++ Il cliente "+getName()+
              " di tipo B va a bere allo zampillo "+zamp);
            Util.sleep(RIEMPIMENTO);
              // beve
            System.out.println("--- Il cliente "+getName()+
              " di tipo B lascia lo zampillo "+zamp);
            fineRiempimento();
              // lascia la fontana  
        } //[m] run
                    
    } // {c} ClienteBTh
        
    /**[m]
     * ingresso in coda A
     * @return lo zampillo assegnato
     */
    public int entraCodaA()
    {
        mEnter();
        // verifica la condizione di attesa per A
        if (clientiA>0 || zampilliLiberi==0 || (clientiB>0 && stat!=0))
        {
            // deve attendere
            clientiA++;
            System.out.println("vvv Il cliente "+Thread.currentThread().getName()+
              " di tipo A attende in coda (clientiA="+clientiA+")");
            attesaA.cWait();
            clientiA--;
            System.out.println("^^^ Il cliente "+Thread.currentThread().getName()+
              " di tipo A termina l'attesa in coda (clientiA="+clientiA+")");
        }
        // assegna zampillo in mutua esclusione
        zampilliLiberi--;
        // reset di stat
        stat=2;
        System.out.println("************ zampilli liberi = "+zampilliLiberi);
        int zamp = (ultimoZampillo = (ultimoZampillo+1)%8)+1;
        mExit();
        return zamp;
    } //[m] entraCodaA
    
    /**[m]
     * ingresso in coda B
     * @return lo zampillo assegnato
     */
    public int entraCodaB()
    {
        mEnter();
        // verifica la condizione di attesa sul semaforo privato tipo B
        if (clientiB>0 || zampilliLiberi==0 || (clientiA>0 && stat==0))
        {
            // deve attendere
            clientiB++;
            System.out.println("vvv Il cliente "+Thread.currentThread().getName()+
              " di tipo B attende in coda (clientiB="+clientiB+")");
            attesaB.cWait();
            clientiB--;
            System.out.println("^^^ Il cliente "+Thread.currentThread().getName()+
              " di tipo B termina l'attesa in coda (clientiB="+clientiB+")");
        }
        // assegna zampillo in mutua esclusione
        zampilliLiberi--;
        System.out.println("************ zampilli liberi = "+zampilliLiberi);
        if (clientiA>0)
            stat--;  // conteggio specifico
        int zamp = (ultimoZampillo = (ultimoZampillo+1)%8)+1;
        mExit();
        return zamp;
    } //[m] entraCodaB
    
    /**[m]
     * lascia la fontana
     */
    public void fineRiempimento()
    {
        mEnter();
        zampilliLiberi++;
          // uno zampillo liberato
        System.out.println("************ zampilli liberi = "+zampilliLiberi);
        // valuta condizione per il rilascio di un cliente B
        // che ha priorita`
        if (clientiB>0 && (clientiA==0 || stat!=0))
            // cede al cliente risvegliato la mutua esclusione
            attesaB.cSignal();
        // valuta condizione per il rilascio di un cliente A
        else if (clientiA>0)
            // cede al cliente risvegliato la mutua esclusione
            attesaA.cSignal();
        mExit();
    } //[m] fineRiempimento

    /**[m][s]
     * main di collaudo
     */
    public static void main(String[] args) 
    {
        System.err.println("** Battere Ctrl-C per terminare!");
        FontanaMon fo = new FontanaMon();
        int cnt=1;
        for(;;)
        {
            Util.rsleep(500, 2000);
            if (Util.randVal(1,2) == 1)
                fo.new ClienteATh("num"+(cnt++)).start();
            else
                fo.new ClienteBTh("num"+(cnt++)).start();
        }
    } //[m][s] main
    
} //{c} FontanaMon
