import os.*;

public class Salita
{
   private static final int NUMMAXUTENTI = 20;
   private static final int LIVELLI = 11;
   public static final int ENTRATIM = 5000;
   public static final int PIANOT = 1000;//IANOT costante corrispondente alla discesa di un piano;
   public static final int DISCESA = 1000;//DISCESA � il tempo consentito per la discesa degli utenti al piano
   
   public static final int CAP = 6;
   public static final int MAXWAIT = 3000;
   //numero di utenti in P e in S,
   private int prenP = 0;
   private int prenS = 0;
   //ticketing per mantenere l�ordine
   private int ticketP = 0;
   private int ticketS = 0;
   private int servP = 0;
   private int servS = 0;
   
   private int num = 0;//l�occupazione (progressiva) dell�ascensore
   private int arrivato = 0;//piano corrente di fermata
   
   private int pren[];//pren[i] quanti utenti in una corsa di ascensore vogliono salire al piano i;
   
   private boolean aperto = true;//true quando l�ascensore sta caricando
   
   //costruttore della salita
   public Salita()
   {
      pren = new int[LIVELLI];
      for(int i = 0; i< LIVELLI; i++)
         pren[i] = 0;
   }
   
      
   public class Utente extends Thread
   {
      private int io;
      private int piano;
      public Utente(int io, int piano)
      {
         super("Utente_"+(piano<=5?"P_":"S_")+io);
         System.out.println("Crea "+getName());
         this.io = io;
         this.piano = piano;
      }
      
      public void run()
      {
         System.out.println("Attivato "+getName()+" ora va in coda, piano="+piano);
         
         if(this.piano>0 && this.piano < 6)
            inCodaP(this.piano);
         else if(this.piano>5 && this.piano < 11)
            inCodaS(this.piano);
            
         System.out.println("1> Ora "+getName()+" va all'ascensore");
         entra(this.piano);
         System.out.println("2> Ora "+getName()+" e' arrivato");
      }
   }
   
   public class Ascensore extends Thread
   {
      public Ascensore()
      {
         super("Ascensore");
         System.out.println("Crea "+getName());
      }
      
      public void run()
      {
         System.out.println("Attivato "+getName());
         while(true)
         {
            //simula l�attesa per caricamento
            //simula salita ai vari piani
            servizio();
            
            //discesa dall�ultimo piano visitato al piano terra
            discesa();
         }
      }
   }
   
   public synchronized void inCodaP(int piano)
   {
      int myTicket = ticketP++;
      prenP++;
      System.out.println("1*** CodaP "+Thread.currentThread().getName()+" ticket="+myTicket);
      
      while(!(aperto && num < CAP && prenS == 0 && servP == myTicket))
      {
         //l'ingresso e' possibile se l'ascensore e' aperto e non pieno,
         // e se non ci sono prenotazioni prioritarie
         try {wait();}catch(InterruptedException e){};
      }
      prenP--;
      servP++;
      num++;
      pren[piano]++;
      System.out.println("2*** CodaP "+Thread.currentThread().getName()+ " puo' entrare ticket="+myTicket+" num="+num);
   }
   
   public synchronized void inCodaS(int piano)
   {
      int myTicket = ticketS++;
      prenS++;
      System.out.println("1*** CodaS "+Thread.currentThread().getName()+" ticket="+myTicket);
      
      while(!(aperto && num < CAP && servS == myTicket))
      {
         //l'ingresso e' possibile se l'ascensore e' aperto e non pieno,
         // e se non ci sono prenotazioni prioritarie
         try {wait();}catch(InterruptedException e){};
      }
      prenS--;
      servS++;
      num++;
      pren[piano]++;
      System.out.println("2*** CodaS "+Thread.currentThread().getName()+ " puo' entrare ticket="+myTicket+" num="+num);

   }
   
   //simula l�ingresso di un utente nell�ascensore
   public synchronized void entra(int piano)
   {
      // di norma non si mettono attese in mutex pero' qui il tempo e' breve, non crea problemi in mutex
      Util.sleep(ENTRATIM);
      
      while(arrivato != piano)
      {
         try{wait();}catch(InterruptedException e){};
      }
      
      //l�attesa fino al momento in cui l�utente arriva al piano richiesto;
   }
   
   //restituisce l�indice del piano inferiore che ha
   // prenotazioni pendenti come indicato dal parametro pr
   public int minPren(int pr[])
   {
      for(int i = 1; i < LIVELLI; i++)
         if(pr[i] != 0)
            return i;
      return -1;
   }
   
   
   //l�attesa dell�ascensore per il carico seguita dalla visita 
   //nell�ordine di tutti i piani prenotati
   public void servizio()
   {
      int quanti =0, min= 0;
      
      System.out.println("1=== servizio "+Thread.currentThread().getName()+ " attende riempimento");
      
      while(true)
      {
         //si noti che le sincronizzazioni avvengono sull'unica istanza di classe Salita
         synchronized(this) {
            // da' modo agli utenti in eventuale attesa di entrare
            notifyAll();
         }
         
         if (prenP+prenS==0 && num < CAP)
         // al momento non ci sono prenotazioni per ingresso
         // ma ancora spazio
            Util.sleep(MAXWAIT);
            
         if ((prenP+prenS==0 && num!=0) || num == CAP)
            // dopo l'attesa non ci sono prenotazioni
            // ma ci sono gia' utenti nell'ascensore
            // oppure l'ascensore e' pieno: deve partire
            break;
      }
      
      aperto = false;
      System.out.println("2=== servizio "+Thread.currentThread().getName()+" si muove");
      
      while(true)
      {
         if ((min = minPren(pren)) == -1)
            break;
         System.out.println("3=== servizio "+Thread.currentThread().getName()+" da "+arrivato+         " sale al piano "+min+" e scarica "+pren[min]+" utenti");
         Util.sleep((min-arrivato)*PIANOT+DISCESA);//piani fino ad adesso passati
         // simula una tratta
         // raggiunto un piano richiesto
         pren[min]=0;
         arrivato = min;
         synchronized(this) 
         {
            // consente agli utenti che devono scendere
            // di farlo
            notifyAll();
         }
      }
      System.out.println("4=== servizio "+Thread.currentThread().getName()+" completato servizio");
   }
   
   //discesa dell�ascensore dall�ultimo piano visitato al piano terra
   public void discesa()
   {
      if(arrivato != 0)
      {
         System.out.println(Thread.currentThread().getName()+" scende");
         //discesa con durata = n*PIANOT
         Util.sleep(arrivato*PIANOT);//discesa sesta soste
         
         arrivato = 0;
         aperto = true;
      }
            // n piano di partenza nella discesa
   }
   
   public static void main(String[] args)
   {
      if(args.length < 2)
         System.out.println("Mancano parametri da riga di comando: ex >min max");
      else
      {

         int min = Integer.parseInt(args[0]);
         int max = Integer.parseInt(args[1]);
         
         if(min > max)
         {
            int tmp = min;
            min = max;
            max = tmp;
         }
         Salita st = new Salita();
         st.new Ascensore().start();
         
         for(int i = 0; i < NUMMAXUTENTI; i++)
         {
            Util.rsleep(min,max);
            st.new Utente(i, Util.randVal(1, LIVELLI-1)).start();
         }
      }
      
   }

}