package MoloMagaz;

import os.Util; 
import os.ada.*;
import os.Timeout; 

/**{c}
 * Magaz, secondo appello 15/16
 * soluzione con Rendez-Vous AdaJava
 * @author M.Moro DEI UNIPD
 * @version 1.00 2016-06-26
 */
 
public class Magaz {
  private static final long TMIN=1000L; 
  private static final long TMAX=10000L;
  private static final String Cname="Magazzino";  // nome del controllore
  private static final int MAXP = 24;
  private static final int QM = 16;
  private static final int QP = 8;
  private int pool = 0;

// parte non richiesta
  
  /**[c]
   */
  public Magaz () {
  } //[c]

  /**{c}
   * thread PezzoA
   */
  private class Lotto extends ADAThread {
  
  private boolean tA;

    /**[c]
     * @param id id del thread
     * @param tyA lotto tipo A
    */
    public Lotto(String id, boolean tyA) {
      super(" "+(tyA ? "A" : "B")+"_"+id);
      tA = tyA;
      System.out.println("*** Il produttore "+id+" � di tipo "+ (tyA ? "A" : "B"));
    }
  
    /**[m]
     * produzione
     */
    public void run() {
      int pp;
      while(true) 
      {
        Util.rsleep(TMIN, TMAX);
        if (tA)
            pp = Util.randVal(QP, QM);
        else
            pp = Util.randVal(1, QM-1);
        System.out.println("+++ "+getName()+" produce pp="+pp);
        CallOut out = entryCall(new Integer(pp), Cname, "PROD");
        if (tA)
        {
            System.out.println("+++ "+getName()+" LOTTOA chiede autoriz");
            out = entryCall(null, Cname, "LOTTOA");
            System.out.println("+++ "+getName()+" OTTENUTA!!!!");
        }
      }
    } //[m] run
  } // {c} Lotto

  /**{c}
   * thread Servente
   */
  private class Serv extends ADAThread {
 //   private boolean goA  = true;  // inizia da A
 //   private int cntA=0, cntB=0;     // conteggio pezzi
    int pool = 0;
    
    /**[c]
     * @param name identificativo del controllore 
     */
    public Serv (String name) {
      super(name);
      System.out.println("*** Controllore "+getName()+" inizializzato");
    } //[c]
    
    public void run() {
      Select request = new Select();
      //**** Scrittura codice per "componenti" 

      Guard grdPr = new Guard() { 
        public boolean when() {
          return pool<=MAXP-QM; // per produrre
        }};

      Entry entPr = new Entry() {    //*0  entry "PROD"
        public Object exec(Object inp) {
          int inc = (Integer)inp;
          pool += inc;
          System.out.println("^^^ PROD inp="+inc+" pool="+pool);
          return null;
      }};
      
      Guard grdLa = new Guard() { 
        public boolean when() {
          return pool<QM/4; // blocco lotto A
        }};

      Entry entLa = new Entry() {    //*1  entry "LOTTOA"
        public Object exec(Object inp) {
          System.out.println("!!! LOTTOA sbloccato");
          return null;
      }};
      
      Guard grdPl = new Guard() { 
        public boolean when() {
          return pool>0; // prelievo possibile
        }};

      Entry entPl = new Entry() {    //*3  entry "PREL"
        public Object exec(Object inp) {
          pool--;
          System.out.println("--- PREL pool="+pool);
          return null;
      }};
      
      request.add(grdPr, "PROD", entPr); 
      request.add(grdLa, "LOTTOA", entLa); 
      request.add(grdPl, "PREL", entPl); 
      
      while(true) {                       // inizia l'attivita'�
        request.accept();
      } // while
    } //[m] run
    
  } // {c} Serv 

  /**[m][s]
   * main di collaudo
   */
  public static void main(String[] args) {
    Magaz mag = new Magaz();
    System.out.println("*** Soluzione con Rendez-Vous AdaJava");
    System.err.println("*** Ctrl-C termina la simulazione!");
    ADAThread ss = mag.new Serv(Cname);
    ss.start();
    Util.sleep(1000L);
    mag.new Lotto("11", true).start();
//    mag.new Lotto("12", true).start();
//    mag.new Lotto("13", true).start();
    mag.new Lotto("21", false).start();
//    mag.new Lotto("22", false).start();
    for(int i=0; ; i++)
    {
        Util.rsleep(TMIN/8, TMAX/8);
        CallOut out = ss.entryCall(null, Cname, "PREL");
    }
    
  } //[m][s] main

} //{c} Magaz

