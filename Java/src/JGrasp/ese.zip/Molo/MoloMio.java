import os.*;

public class MoloMio
{
   private MutexSem m;//mutex
   private Semaphore att[];//attese di accesso al servizio
   private Semaphore stopGru[];
   private Semaphore servito[];
   
   private int truckD;//num. merci deperibili
   private int truckS;//num.merci standard
   
   private boolean puntoDiCarico[];
   
   private int tMin, tMax;
   
   public MoloMio(long minT, long maxT)
   {
      m = new MutexSem(true);//mutex
      
      att = new Semaphore[2];//attese di accesso al servizio
      stopGru = new Semaphore[2];
      for(int i = 0; i < 2; i++)
      {
         //specifico il min ed il max
         att[i] = new Semaphore(0,1);
         stopGru[i] = new Semaphore(0,1);
      }
      servito = new Semaphore[3];
      puntoDiCarico = new boolean[3];
      for(int i = 0; i < 3; i++)
      {
         servito[i] = new Semaphore(0,1);
         puntoDiCarico[i] = true;
      }
      
      truckD = 0;//num. merci deperibili
      truckS = 0;//num.merci standard
   
      
      tMin=minT;
      tMax=maxT;
   }
   
   public class Camion extends Thread
   {
      private boolean isDeperibile;
      private int i;
      
      public Camion(boolean isDep, int i)
      {
         this.isDeperibile = isDep;
         this.i = i;
      }
      
      public void run()
      {
         int pos = entra(this.isDeperibile);
         esce(pos);
      }
   }
   
   public int entra(boolean richiestaA)
   {
      m.p();
      int pos;
       m.v();
       return pos;
   }
   
   public int esce(int punto)
   {
      m.p();
      
      m.v();
   }
   
   public class Gru extends Thread
   {  
      private int i;
      
      public Gru(int i)
      {
         super("Gru" + i);
         this.i = i;
      }
   
      public void run()
      {
         //le gru essendo due, ed essendo tre i punti di carico
         //le gru possono spostarsi al pi� in due slot limitrofi
         //ragion per cui uso left e right per dire quali solo i possibili
         //punti di carico per quella gru
         int left, right;
         if(this.i == 1)
         {
            left = 0;
            right = 1;
         }
         else
         {
            left = 1;
            right = 2;
         }
         
         while(true)
         {
            stopGru[i-1].p();
            
            for(int j = left, j <= right; j++)
            {
               mutex.p();
               
            }
         
         }
      }
   }
   
   public static void main(String[] args)
   {
      if(args.length != 2)
         System.out.println("Errore");
      else
      {
         MoloMio molo = new MoloMio(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
         for(int i = 1; i < 3; i++)
            molo.new Gru(i).start();
            
         for(int i = 0; i< 20; i++)
         {
            int case = Util.randVal(0,1);
            boolean b;
            if(case == 0)
               b = false;
            else
               b = true;
            molo.new Camion(b, i).start();
            
            Util.rsleep(500,5000);
         }
      }
      
   }
   
}