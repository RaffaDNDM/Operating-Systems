import os.*;

public class SmistaMonitorJava
{
   private boolean I1, I2;
   private boolean B[], C[];
   private final int dimB=2, dimC=3;
   private int Bdest[];
   
   private final int I1ATT = 1000, I2ATT = 1000;
   private final int BMIN = 2000, BMAX = 2000;
   private final int CMIN = 3000, CMAX = 3000;
   
   private int ContAttA[];
   private int ContAttB[];
   
   private int ticketA[];
   private int servizioA[];

   
   public SmistaMonitorJava()
   {
      I1 = true;
      I2 = true;
      B = new boolean[dimB];
      Bdest = new int[dimB];

      for(int i = 0; i< dimB; i++)
      {
         B[i] = true;
         Bdest[i] = -1;
      }
      C = new boolean[dimC];
      for(int i = 0; i< dimC; i++)
         C[i] = true;
     
      ContAttA = new int[3];
      ticketA = new int[3];
      servizioA = new int[3];
      
      for(int i = 0; i< 3; i++)
      {
         ContAttA[i] = 0;
         ticketA[i] = 0;
         servizioA[i] = 0;
      }
      
      ContAttB = new int[2];
      for(int i = 0; i< 2; i++)
         ContAttB[i] = 0;
         
   }
   
   public class Carrello extends Thread
   {
      private String name;
      private int i;
      
      public Carrello(String name, int i)
      {
         super(name);
         this.name = name;
         this.i = i;
      }
      
      public void run()
      {
         System.out.println("Carrello" + name + " entra in coda " + i);
         int h = instrada(i);//in quale b dovrei andare
         System.out.println("Carrello" + name + " esce dalla coda. va in I1");
         Util.sleep(I1ATT);
         
         System.out.println("Carrello" + name + " esce da I1, verso B"+h);
         outI1(h);//dopo i1 dove vado
         
         Util.rsleep(BMIN, BMAX);
         int iCheck = outB(h);//da quale b esco
         
         if(iCheck != i)
            System.out.println("Errore nelle code");

         System.out.println("Carrello" + name + " esce dalla coda B" +h +" e va in I2");
         Util.sleep(I2ATT);
         
         System.out.println("Carrello" + name + " esce da I2, verso C"+iCheck);   
         //dovrei controllare che i tronato sia uguale
         inC(iCheck);
         
         Util.rsleep(CMIN, CMAX);
         System.out.println("Carrello" + name + " esce dalla C" +iCheck);
         outC(iCheck);
      }
   }
   
   public synchronized int instrada(final int i)
   {
      int ticket = ticketA[i];
      ticketA[i]++;
      ContAttA[i]++;
      
      /*System.out.println("i1"+!I1);
      System.out.println("PRIMO "+(!B[0] && !B[1]));
       System.out.println("SECONDO "+ !C[i]);
        System.out.println("TERZO "+(servizioA[i] != ticketA[i]));*/

      while(!I1 || (!B[0] && !B[1]) || !C[i] || servizioA[i] != ticket)
      {
         try{wait();}
         catch(InterruptedException e){}
      }
      
      ContAttA[i]--;
      servizioA[i]++;
      I1 = false;
      int h = 0;
      
      if(B[0])
         h=0;
      else
         h = 1;
      Bdest[h] = i;
      
      return h;
   }   
   public synchronized void outI1 (int h)
   {      
      I1 = true;
      B[h] = false;
      notifyAll();      
   }
   
   public synchronized int outB (int h)
   {
      while(!I2)//c i deve essere gi� libero
         try{wait();}catch(InterruptedException e){}
      
      B[h] = true;
      I2 = false;
      int ret = Bdest[h];
      Bdest[h] = -1;

      return ret; 
   }
   
   public synchronized void inC (int i)
   {
      I2 = true;
      C[i] = false;
      
      notifyAll();    
   }
   
   public synchronized void outC (int i)
   {
      C[i] = true;
   }
   
   
   public static void main(String[] args)
   {
      SmistaMonitorJava s = new SmistaMonitorJava();
      
      for(int i = 0; i < 50; i++)
      {
         int index = Util.randVal(0,2);
         System.out.println("Creato carrello" + i);
         
         s.new Carrello("carrello" + i, index).start();
         Util.rsleep(500,2000);
      }
   }
}