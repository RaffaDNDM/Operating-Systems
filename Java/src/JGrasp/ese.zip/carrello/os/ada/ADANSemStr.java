package os.ada;

/**{c}
 * semaforo numerico in Ada
 * stringhe utili
 * @author M.Moro DEI UNIPD
 * @version 1.00 2010-12-23
*/

public interface ADANSemStr
{
    static final String pStr = "p";
      // nome del selettore di p()
    static final String vStr = "v";
      // nome del selettore di v()
    static final String valStr = "val";
      // nome del selettore di stato
      
} //{c} ADANSemStr
