import os.*;

public class Smista extends Monitor
{
   private boolean I1, I2;
   private boolean B[];
   private int Bdest[];
   private boolean C[];
   
   private final int I1ATT = 1000, I2ATT = 1000;
   private final int BMIN = 2000, BMAX = 2000;
   private final int CMIN = 3000, CMAX = 3000;
   
   private Condition attA[];
   private Condition attB[];
   
   public Smista()
   {
      I1 = true;
      I2 = true;
      B = new boolean[2];
      Bdest = new int[2];

      for(int i = 0; i< 2; i++)
      {
         B[i] = true;
         Bdest[i] = -1;
      }
      C = new boolean[3];
      for(int i = 0; i< 3; i++)
         C[i] = true;
     
      attA = new Condition[3];
      for(int i = 0; i< 3; i++)
         attA[i] = new Condition();
      attB = new Condition[2];
      for(int i = 0; i< 2; i++)
         attB[i] = new Condition();
   }
   
   public class Carrello extends Thread
   {
      private String name;
      private int i;
      
      public Carrello(String name, int i)
      {
         this.name = name;
         this.i = i;
      }
      
      public void run()
      {
         System.out.println("Carrello" + name + " entra in coda " + i);
         int h = instrada(i);//in quale b dovrei andare
         System.out.println("Carrello" + name + " esce dalla coda. va in I1");
         Util.sleep(I1ATT);
         
         System.out.println("Carrello" + name + " esce da I1, verso B"+h);
         outI1(h);//dopo i1 dove vado
         
         Util.rsleep(BMIN, BMAX);
         int iCheck = outB(h);//da quale b esco
         
         if(iCheck != i)
            System.out.println("Errore nelle code");

         System.out.println("Carrello" + name + " esce dalla coda B" +h +" e va in I2");
         Util.sleep(I2ATT);
         
         System.out.println("Carrello" + name + " esce da I2, verso C"+iCheck);   
         //dovrei controllare che i tronato sia uguale
         inC(iCheck);
         
         Util.rsleep(CMIN, CMAX);
         System.out.println("Carrello" + name + " esce dalla C" +iCheck);
         outC(iCheck);
      }
   }
   
   public int instrada(final int i)
   {
      mEnter();
      
      if(!I1 || (!B[0] && !B[1]) || !C[i])
         attA[i].cWait();
      
      I1 = false;
      int h = 0;
      if(B[0])
      {
         h=0;
         Bdest[h] = i;
      }
      else
      {
         h = 1;
         Bdest[h] = i;
      }
               
      mExit();
      return h;
   }   
   public void outI1 (int h)
   {
      mEnter();
      
      I1 = true;
      B[h] = false;
      
      for(int i = 0; i < 3;i++)
         attA[i].cSignal();      
      mExit();
   }
   
   public int outB (int h)
   {
      mEnter();

      if(!I2)//c i deve essere gi� libero
         attB[h].cWait();
      B[h] = true;
      I2 = false;
      int ret = Bdest[h];
      Bdest[h] = -1;
      mExit();
      return ret; 
   }
   
   public void inC (int i)
   {
      mEnter();
      I2 = true;
      C[i] = false;
      
      for(int j = 0; j < 2;j++)
         attB[j].cSignal();   
      
      mExit();
   }
   
   public void outC (int i)
   {
      mEnter();
      C[i] = true;
      mExit();
   }
   
   
   public static void main(String[] args)
   {
      Smista s = new Smista();
      
      for(int i = 0; i < 50; i++)
      {
         int index = Util.randVal(0,2);
         System.out.println("Creato carrello" + i);
         
         s.new Carrello("carrello" + i, index).start();
         Util.rsleep(500,5000);
      }
   }
}