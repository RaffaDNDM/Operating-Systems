import java.util.Date;
import os.Semaphore; 
import os.MutexSem; 
import os.Util; 
 
/**{c}
 * SportelliSem, esempio di coda con piu' sportelli
 * soluzione con semafori 
 * @author M.Moro DEI UNIPD
 * @version 1.00 2011-04-13
 */
 
public class SportelliSem
{
    private int numSport;
      // sportelli gestiti
    private MutexSem mutex = new MutexSem();
      // protezione della sezione critica
    private Semaphore coda;
      // semaforo numerico che rappresenta la coda
    private boolean free[];
      // stato sportelli
      
    /**[c]
     * @param ns  numero degli sportelli
     */
    public SportelliSem(int ns)
    {
        numSport = ns;
        free = new boolean[ns];
        for (int i=0; i<ns; free[i++] = true);
        coda = new Semaphore(ns);
    }
        
    /**{c}
     * thread cliente
     */
    private class ClienteTh extends Thread
    {
        long minAtt, maxAtt;
          // tempi di attesa
        
        /**[c]
         * @param name  nome del cliente
         * @param min  tempo di attesa minimo
         * @param max  tempo di attesa massimo
         */
        public ClienteTh(String name, long min, long max)
        {
            super(name);
            minAtt = min;
            maxAtt = max;
        }
        
        /**[m]
         * test: si mette in coda per uno sportello
         */
        public void run()
        {
            System.out.println("!!! Il cliente "+getName()+" va in coda t="+
              new Date());
            int sportello=entraCoda();
            System.out.println("+++ Il cliente "+getName()+
              " viene servito dallo sportello "+sportello+
              " t="+new Date());
            Util.rsleep(minAtt, maxAtt);
              // servizio
            System.out.println("--- Il cliente "+getName()+
              " ha finito allo sportello "+sportello);
            esce(sportello);
              // lascia il servizio  
        } //[m] run
                    
    } // {c} ClienteTh
        
    /**[m]
     * ingresso in coda 
     * @return lo sportello scelto
     */
    public int entraCoda()
    {
        int sport;
        
        coda.p();
          // entra nella coda
        mutex.p();
          //e' stato fatto passare, sceglie sportello
        for (sport=0; sport<numSport; sport++)
          // uno � senz�altro libero
            if (free[sport])
                break;
        free[sport] = false;
        mutex.v();
        return sport;
    } // [m] entraCoda
    
    /**[m]
     * lascia lo sportello
     * @param sport  sportello lasciato
     */
    public void esce(int sport)
    {
        mutex.p();
          // questa sezione critica non � strettamente necessaria
        free[sport] = true;
        mutex.v();
        coda.v(); // libera uno dalla coda
    } //[m] esce

    /**[m][s]
     * main di collaudo
     */
    public static void main(String[] args) 
    {
        System.err.println("** Battere Ctrl-C per terminare!");
        SportelliSem sp = new SportelliSem(4);
        int cnt=1;
        for(;;)
        {
            Util.rsleep(500, 3000);
            sp.new ClienteTh("num"+(cnt++), 1000, 10000).start();
        }
    } //[m][s] main
    
} //{c} SportelliSem
