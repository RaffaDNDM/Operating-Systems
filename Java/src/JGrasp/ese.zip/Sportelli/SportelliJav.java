import java.util.Date;
import os.Util;

/**{c}
 * SportelliJav, esempio di coda con piu' sportelli
 * soluzione con monitor di Java
 * @author M.Moro DEI UNIPD
 * @version 1.00 2012-03-29
 */

//
public class SportelliJav
{
    private int numSport;
    // sportelli gestiti
    private int numLiberi;
    // sportelli liberi
    private boolean free[];
    // stato sportelli

    /**[c]
     * @param ns  numero degli sportelli
     */
    public SportelliJav(int ns)
    {
        numSport = numLiberi = ns;
        free = new boolean[ns];
        for (int i=0; i<ns; free[i++] = true);
    }

    /**{c}
     * thread cliente
     */
    private class ClienteTh extends Thread
    {
        long minAtt, maxAtt;
        // tempi di attesa

        /**[c]
         * @param name  nome del cliente
         * @param min  tempo di attesa minimo
         * @param max  tempo di attesa massimo
         */
        public ClienteTh(String name, long min, long max)
        {
            super(name);
            minAtt = min;
            maxAtt = max;
        }

        /**[m]
         * test: si mette in coda per uno sportello
         */
        public void run()
        {
            System.out.println("!!! Il cliente "+getName()+" va in coda t="+
                    new Date());
            int sportello=entraCoda();
            System.out.println("+++ Il cliente "+getName()+
                    " viene servito dallo sportello "+sportello+
                    " t="+new Date());
            Util.rsleep(minAtt, maxAtt);
            // servizio
            System.out.println("--- Il cliente "+getName()+
                    " ha finito allo sportello "+sportello);
            esce(sportello);
            // lascia il servizio
        } //[m] run

    } // {c} ClienteTh

    /**[m]
     * ingresso in coda
     * @return lo sportello scelto
     */


    public synchronized int entraCoda()
    {
        int sport;

        //IL RISVEGLIATO COMPETE PER ENTRARE IN MUTUA ESCLUSIONE
        while (numLiberi == 0)//ANDREBBE CONTROLALTO SE IL VALORE DEL TICKET CORRISPONDE AL VALORE ATTUALE DEL THREAD
            try { wait(); } catch (InterruptedException e) {};//e' stato fatto passare, sceglie sportello

        //QUI DOVREI ASSEGNARE IL TICKET AL THREAD
        numLiberi--;
        for (sport=0; sport<numSport; sport++)
            // uno � senz�altro libero
            if (free[sport])
                break;
        free[sport] = false;
        return sport;
    } // [m] entraCoda

    /**[m]
     * lascia lo sportello
     * @param sport  sportello lasciato
     */
    public synchronized void esce(int sport)
    {
        free[sport] = true;
        numLiberi++;
        notify();//UNICO MOTIVO DI ATTESA è PERCHè SONO CLIENTI IN ATTESA, UNICA CONDIZIONE
        //NON DA CERTEZZA NELL'ORDINE DI RISVEGLIOOOOO!!!!

        //PER GESTIRE STA COSA SAREBBE NECESSARIO ASSEGNARE AI THREAD UN ORDINE DI ARRIVO PER POTER ASSICURARE
        //CHE LA CODA FIFO SIA RISPETTATA
        //DOVREI PERò RISVEGLIARE TUTTI I PROCESSI, SONO QUELLO CORRETTO HA LA CONDIZIONE VERIFICATA
    } //[m] esce

    /**[m][s]
     * main di collaudo
     */
    public static void main(String[] args)
    {
        System.err.println("** Battere Ctrl-C per terminare!");
        SportelliJav sp = new SportelliJav(4);
        int cnt=1;
        for(;;)
        {
            Util.rsleep(500, 3000);
            sp.new ClienteTh("num"+(cnt++), 1000, 10000).start();
        }
    } //[m][s] main

} //{c} SportelliJav

