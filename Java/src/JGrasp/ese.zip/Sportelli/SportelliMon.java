import java.util.Date;
import os.Monitor;
import os.Util;

/**{c}
 * SportelliMon, esempio di coda con piu' sportelli
 * soluzione con Monitor 
 * @author M.Moro DEI UNIPD
 * @version 1.00 2011-04-13
 */

//RISPETTO A PRIMA LA CONDITION VARIABLE NON HA ALCUN VALORE NUMERICO ASSOCIATO-->PERCHè è UNA CODA DI ATTESA
//NON POSSO PASSARE L'INTERO ALLA CODA

//INCLUDE LA CLASSE STESSA IL MONITOR
public class SportelliMon extends Monitor
{
    private int numSport;      // sportelli gestiti
    private int numLiberi;      // sportelli liberi PRIMA NON C'ERA
    private Condition coda = new Condition();      // coda di attesa , SI APPLICA DA SOLA IL MONITOR
    //PERCHè EREDITA
    private boolean free[];
    // stato sportelli

    /**[c]
     * @param ns  numero degli sportelli
     */
    public SportelliMon(int ns)
    {
        numSport = numLiberi = ns;
        free = new boolean[ns];
        for (int i=0; i<ns; free[i++] = true);
    }

    /**{c}
     * thread cliente
     */
    private class ClienteTh extends Thread
    {
        long minAtt, maxAtt;
        // tempi di attesa

        /**[c]
         * @param name  nome del cliente
         * @param min  tempo di attesa minimo
         * @param max  tempo di attesa massimo
         */
        public ClienteTh(String name, long min, long max)
        {
            super(name);
            minAtt = min;
            maxAtt = max;
        }

        /**[m]
         * test: si mette in coda per uno sportello
         */
        public void run()
        {
            System.out.println("!!! Il cliente "+getName()+" va in coda t="+
                    new Date());
            int sportello=entraCoda();
            System.out.println("+++ Il cliente "+getName()+
                    " viene servito dallo sportello "+sportello+
                    " t="+new Date());
            Util.rsleep(minAtt, maxAtt);
            // servizio
            System.out.println("--- Il cliente "+getName()+
                    " ha finito allo sportello "+sportello);
            esce(sportello);
            // lascia il servizio
        } //[m] run

    } // {c} ClienteTh

    /**[m]
     * ingresso in coda
     * @return lo sportello scelto
     */
    public int entraCoda()
    {
        int sport;

        //DEVE ESSERE UN METODO ENTRY, GARANTISCE MUTUA ESCLUSIONE
        mEnter();
        if (numLiberi == 0)
            //ATTENDO SE NESSUNO SPORTELLO LIBERO
            coda.cWait(); //e' stato fatto passare, sceglie sportello

        //POSSO DECREMENTARE PERCHè DEVE ESSERE DIVENTATO MAGGIORE DI 0 (QUALCUNO LO INCREMNETA
        numLiberi--;
        for (sport=0; sport<numSport; sport++)
            // uno � senz�altro libero
            if (free[sport])
                break;
        free[sport] = false;
        mExit();
        return sport;
    } // [m] entraCoda

    /**[m]
     * lascia lo sportello
     * @param sport  sportello lasciato
     */
    public void esce(int sport)
    {
        mEnter();
        free[sport] = true;
        numLiberi++;//ECCO CHI AGGIORNAVA LA CONDIZIONE
        coda.cSignal();  // libera uno dalla coda
        //COMPORTEREBBE CHE ATTIVA UN THREAD CHE PRIMA ERA IN ATTESA
        mExit();
    } //[m] esce

    /**[m][s]
     * main di collaudo
     */
    public static void main(String[] args)
    {
        System.err.println("** Battere Ctrl-C per terminare!");
        SportelliMon sp = new SportelliMon(4);
        int cnt=1;
        for(;;)
        {
            Util.rsleep(500, 3000);
            sp.new ClienteTh("num"+(cnt++), 1000, 10000).start();
        }
    } //[m][s] main

} //{c} SportelliMon

