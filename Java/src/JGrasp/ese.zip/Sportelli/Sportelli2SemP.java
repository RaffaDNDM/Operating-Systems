import java.util.Date;
import os.Semaphore; 
import os.Util; 
 
/**{c}
 * Sportelli2SemP, esempio di coda con piu' sportelli
 * variante con due code, una pi� prioritaria (freccia club)
 * soluzione con semafori privatei
 * @author M.Moro DEI UNIPD
 * @version 1.00 2016-03-22
 */
 
public class Sportelli2SemP
{
    private int numSport, freeS;
      // sportelli gestiti, sportelli liberi
    private Semaphore mutex = new Semaphore(true);
      // protezione della sezione critica
    private Semaphore coda = new Semaphore(false), 
      codaP = new Semaphore(false);
      // semafori privati per coda normale e prioritaria
    private int susp=0, suspP=0;
      // conteggio sospesi
    private boolean free[];
      // stato sportelli
      
    /**[c]
     * @param ns  numero degli sportelli
     */
    public Sportelli2SemP(int ns)
    {
        numSport = freeS = ns;
        free = new boolean[ns];
        for (int i=0; i<ns; free[i++] = true);
    }
        
    /**{c}
     * thread cliente
     */
    private class ClienteTh extends Thread
    {
        boolean prio;
          // se prioritario
        long minAtt, maxAtt;
          // tempi di attesa
        
        /**[c]
         * @param name  nome del cliente
         * @param p  se prioritario
         * @param min  tempo di attesa minimo
         * @param max  tempo di attesa massimo
         */
        public ClienteTh(String name, boolean p, long min, long max)
        {
            super(name);
            prio = p;
            minAtt = min;
            maxAtt = max;
        }
        
        /**[m]
         * test: si mette in coda per uno sportello
         */
        public void run()
        {
            System.out.println("!!! Il cliente "+getName()+
             (prio?" prioritario ":" ")+"va in coda t="+
              new Date());
            int sportello=prio ? entraCodaP() : entraCoda();
            System.out.println("+++ Il cliente "+getName()+
              " viene servito dallo sportello "+sportello+
              " t="+new Date());
            Util.rsleep(minAtt, maxAtt);
              // servizio
            System.out.println("--- Il cliente "+getName()+
              " ha finito allo sportello "+sportello);
            esce(sportello);
              // lascia il servizio  
        } //[m] run
                    
    } // {c} ClienteTh
        
    /**[m]
     * ingresso in coda normale
     * @return lo sportello scelto
     */
    public int entraCoda()
    {
        int sport;
        
        mutex.p();
        if (freeS==0)
        {
            // deve attendere
            susp++;
            mutex.v();
            coda.p();
              // si accoda
            susp--;
        }
        // e' in mutua esclusione
        freeS--;
          //e' stato fatto passare, sceglie sportello
        for (sport=0; sport<numSport; sport++)
          // uno � senz�altro libero
            if (free[sport])
                break;
        free[sport] = false;
        mutex.v();
        return sport;
    } // [m] entraCoda
    
    /**[m]
     * ingresso in coda prioritaria
     * @return lo sportello scelto
     */
    public int entraCodaP()
    {
        int sport;
        
        mutex.p();
        if (freeS==0)
        {
            // deve attendere
            suspP++;
            mutex.v();
            codaP.p();
              // si accoda
            suspP--;
        }
        // e' in mutua esclusione
        freeS--;
          //e' stato fatto passare, sceglie sportello
        for (sport=0; sport<numSport; sport++)
          // uno � senz�altro libero
            if (free[sport])
                break;
        free[sport] = false;
        mutex.v();
        return sport;
    } // [m] entraCodaP
    
    /**[m]
     * lascia lo sportello
     * @param sport  sportello lasciato
     */
    public void esce(int sport)
    {
        mutex.p();
        free[sport] = true;
        freeS++;
        if (suspP>0)
            // risveglia un prioritario e cede mutex
            codaP.v();
        else if (susp>0)
            // risveglia un normale e cede mutex
            coda.v();
        else
            // esce da mutua esclusione
            mutex.v();
    } //[m] esce

    /**[m][s]
     * main di collaudo
     * @param args  non usato
     */
    public static void main(String[] args) 
    {
        System.err.println("** Battere Ctrl-C per terminare!");
        Sportelli2SemP sp = new Sportelli2SemP(4);
        int cnt=1;
        for(;;)
        {
            boolean prio = Util.randVal(1, 4)<2; // 25% prioritari
            Util.rsleep(500, 2000);
            sp.new ClienteTh("num"+(cnt++), prio, 1000, 10000).start();
        }
    } //[m][s] main
    
} //{c} Sportelli2SemP
