package aeroporto;
import os.*;

public class AeroportoMdj
{
  public static void main (String [] args)
  {
      System.out.println("---- AEROPORTO CON MONITOR DI JAVA ----");
      TorreDiControlloMdj tc = new TorreDiControlloMdj();
      for( int i=1 ; i<=20 ; i++)
      {
          new AereoCheAtterra(i,tc).start();
          Util.rsleep(250, 8000);
          new AereoCheDecolla(20+i,tc).start();
          Util.rsleep(250, 8000);
      }
   }
}
