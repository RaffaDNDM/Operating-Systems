package aeroporto;
import os.*;

public class AeroportoReg
{
    public static void main (String [] args)
    {
        System.out.println("---- AEROPORTO CON REGIONE CRITICA ----");
        TorreDiControlloReg tc = new TorreDiControlloReg();
        for( int i=1 ; i<=20 ; i++)
        {
            new AereoCheAtterra(i,tc).start();
            Util.rsleep(250, 8000);
            new AereoCheDecolla(20+i,tc).start();
            Util.rsleep(250, 8000);
        }
    }
}
