package aeroporto;
import os.*;
  
public class AeroportoSem {
  public static void main (String [] args)
  {
      System.out.println("---- AEROPORTO CON SEMAFORI PRIVATI ----");
      TorreDiControlloSem tc = new TorreDiControlloSem();
      for( int i=1 ; i<=20 ; i++)
      {
          new AereoCheAtterra(i,tc).start();
          Util.rsleep(250, 8000);
          new AereoCheDecolla(20+i,tc).start();
          Util.rsleep(250, 8000);
      }
   }
}
