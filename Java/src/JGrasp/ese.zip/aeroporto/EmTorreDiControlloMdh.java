package aeroporto;
import os.*;

/** {c}
  * TorreDiControlloMdh.java
  * Problema Aeroporto -
  * Torre di controllo con Monitor di Hoare
  * @version 1.00 2003-11-22
  * @author G.Clemente DEI UNIPD
  * @author M.Moro DEI UNIPD
  */

public class EmTorreDiControlloMdh extends TorreDiControllo {
  // non potendo estendere Monitor, ne dichiara una istanza e i necessari Condition




      
  public void richAutorizAtterraggio(int io) {


    System.out.println("$$ L'aereo A"+io+" !!!!!!!! RICHIESTA AUTORIZZAZIONE ATTERRAGGIO");
    stampaSituazioneAeroporto();




    System.out.println("$$$$ L'aereo A"+io+" IN FASE DI ATTERRAGGIO ");
    stampaSituazioneAeroporto();

  }

  public void freniAttivati(int io) {




    System.out.println("$$$$$$ L'aereo A"+io+" TOCCA TERRA, FRENA ");
    stampaSituazioneAeroporto();

  }

  public void inParcheggio(int io) {



    System.out.println("$$$$$$$$ L'aereo A"+io+" LIBERA LA PISTA E PARCHEGGIA");
    stampaSituazioneAeroporto();










  }

  public void richAccessoPista(int io) {


    System.out.println("** L'aereo D"+io+" ^^^^^^^^ RICHIESTA PISTA PER DECOLLO");
    stampaSituazioneAeroporto();



    System.out.println("**** L'aereo D"+io+ " SI PREPARA AL DECOLLO");
    stampaSituazioneAeroporto();

  }

  public void richAutorizDecollo(int io) {


    System.out.println("****** L'aereo D"+io+" RICHIEDE AUTORIZZAZIONE DECOLLO");






    System.out.println("******** L'aereo D"+io+" IN FASE DI DECOLLO ");
    stampaSituazioneAeroporto();




  }

  public void inVolo(int io) {



    System.out.println("********** L'aereo D"+io+ " HA PRESO IL VOLO!!!!! ");
    stampaSituazioneAeroporto();







  }

} //{c} TorreDiControlloMdh
