package aeroporto;
import os.*;


public class TorreDiControlloMdj extends TorreDiControllo {

  public synchronized void richAutorizAtterraggio(int io) {
    riAutAt++;          			// segnala la volont� di atterrare,
    System.out.println("$$ L'aereo A"+io+
      " !!!!!!!! RICHIESTA AUTORIZZAZIONE ATTERRAGGIO");
    stampaSituazioneAeroporto();
    while(occupateA+occupateB != 0)
      try {						// le piste non sono completamente libere
        wait();
      } catch(InterruptedException e) {}
    // blocca pista 
    riAutAt--;						// la pista e` completamente libera
    occupateA=1; att=true;			// la pista ora � riservata
    System.out.println("$$$$ L'aereo A"+io+" IN FASE DI ATTERRAGGIO ");
    stampaSituazioneAeroporto();
  }

  public synchronized void freniAttivati(int io) {
    occupateA=0; occupateB=1;
    // per ragioni di sicurezza, pur passando in B
    // mantiene bloccata la pista con att==true
    System.out.println("$$$$$$ L'aereo A"+io+" TOCCA TERRA, FRENA ");
    stampaSituazioneAeroporto();
  }

  public synchronized void inParcheggio(int io) {
    occupateB=0; att = false;
    contaAtt++;
    System.out.println("$$$$$$$$ L'aereo A"+io+" LIBERA LA PISTA E PARCHEGGIA");
    stampaSituazioneAeroporto();
    notifyAll();
  }

  public synchronized void richAccessoPista(int io) {
    riAccPi++; 					// segnala la volont� di decollare
    System.out.println("** L'aereo D"+io+" ^^^^^^^^ RICHIESTA PISTA PER DECOLLO");
    stampaSituazioneAeroporto();
    while(riAutAt > 0 || att || occupateA == 2) {
      try {
        wait();				// attende gli atterraggi prioritari e la zona A libera
      } catch(InterruptedException e) {}
    }
    riAccPi--;
    occupateA++;; 				// occupa zona A
    System.out.println("**** L'aereo D"+io+ " SI PREPARA AL DECOLLO");
    stampaSituazioneAeroporto();
  }

  public synchronized void richAutorizDecollo(int io) {
    riAutDe++; 					// segnala la volont� di decollare
    System.out.println("****** L'aereo D"+io+" RICHIEDE AUTORIZZAZIONE DECOLLO");
    stampaSituazioneAeroporto();
    while(occupateB == 2)
      try {
        wait();				// deve entrare in zona B
      } catch(InterruptedException e) {}
    riAutDe--;
    occupateA--; occupateB++; 	// libera zona A e occupa zona B
    System.out.println("******** L'aereo D"+io+" IN FASE DI DECOLLO ");
    stampaSituazioneAeroporto();
    notifyAll();
  }

  public synchronized void inVolo(int io) {
    occupateB--; 				// libera zona B
    contaDec++;
    System.out.println("********** L'aereo D"+io+ " HA PRESO IL VOLO!!!!! ");
    stampaSituazioneAeroporto();
    notifyAll();
  }

} //{c} TorreDiControlloMdj
