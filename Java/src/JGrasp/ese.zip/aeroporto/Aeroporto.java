package aeroporto;
import os.*;

public class Aeroporto
{
    private static void usage()
    {
        System.out.println("uso: Aeroporto <n> \n" +
        "n=1 MdH Monitor di Hoare\n"+
        "n=2 MdJ Monitor di Java\n"+
        "n=3 ReC Regioni Critiche\n"+
  //    "n=5 RzV Rendez-Vous in java"+
        "n=4 SeP Semafori Privati\n");
   }
    public static void main (String [] args)
    {
        System.out.println("**** PROBLEMA AEROPORTO IN JAVA ****");
        if (args.length==0)
        {
            usage();
            return;
        }
        usage();
        int ch = Sys.in.readInt("--   inserire n");

        try {
          switch(ch) {
            case 1:
              AeroportoMdh.main(args); break;
            case 2:
              AeroportoMdj.main(args); break;
            case 3:
              AeroportoReg.main(args); break;
    //      case 4:
    //      AeroportoRzv.main(args); break;
            case 5:
              AeroportoSem.main(args); break;
            default:
              usage(); break;
          }
      }
      catch(NumberFormatException e) { usage(); }
    }
}
