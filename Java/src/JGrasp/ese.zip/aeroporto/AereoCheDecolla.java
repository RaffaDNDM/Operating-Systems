package aeroporto;
import os.*;

public class AereoCheDecolla extends Thread
{
    private int io ;
    private TorreDiControllo tc;

    public AereoCheDecolla(int io , TorreDiControllo tc)
    {
        this.io=io;
        this.tc=tc;
    }

    public void run()
    {
        Util.rsleep(1000, 3000);		// si presenta all'ingresso
        tc.richAccessoPista(io);
        Util.rsleep(1000, 3000);		// rulla in posizione
        tc.richAutorizDecollo(io);
        Util.rsleep(1000, 3000);		// in accelerazione: esce da zona A, entra in B
        tc.inVolo(io);					// avvisa la torre di controllo
    }
}
