package aeroporto;
import os.*;

public class EmTorreDiControlloSem extends TorreDiControllo
{
  private static final int MAXACCA = 100;
  private static final int MAXATTAT = 100;			        // massimo accumulo

  public void richAutorizAtterraggio(int io)
  {
    System.out.println("$$ L'aereo A"+io+" !!!!!!!! RICHIESTA AUTORIZZAZIONE ATTERRAGGIO");
    stampaSituazioneAeroporto();
    System.out.println("$$$$ L'aereo A"+io+" IN FASE DI ATTERRAGGIO ");
    stampaSituazioneAeroporto();
  }

  public void freniAttivati(int io)
  {
      System.out.println("$$$$$$ L'aereo A"+io+" TOCCA TERRA, FRENA ");
      stampaSituazioneAeroporto();
  }

  public void inParcheggio(int io)
  {
      System.out.println("$$$$$$$$ L'aereo A"+io+" LIBERA LA PISTA E PARCHEGGIA");
      stampaSituazioneAeroporto();
    }

  public void richAccessoPista(int io)
  {
      System.out.println("** L'aereo D"+io+" ^^^^^^^^ RICHIESTA PISTA PER DECOLLO");
      stampaSituazioneAeroporto();
      System.out.println("**** L'aereo D"+io+ " SI PREPARA AL DECOLLO");
      stampaSituazioneAeroporto();
  }

  public void richAutorizDecollo(int io)
  {
      System.out.println(
      "****** L'aereo D"+io+" RICHIEDE AUTORIZZAZIONE DECOLLO");
      System.out.println("******** L'aereo D"+io+" IN FASE DI DECOLLO ");
      stampaSituazioneAeroporto();
  }

  public void inVolo(int io)
  {
      System.out.println("********** L'aereo D"+io+ " HA PRESO IL VOLO!!!!! ");
      stampaSituazioneAeroporto();
  }

} //{c} TorreDiControlloSem
