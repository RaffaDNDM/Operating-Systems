package aeroporto;
import os.*;

/** {c}
  * TorreDiControlloMdh.java
  * Problema Aeroporto -
  * Torre di controllo con Monitor di Hoare
  * @version 1.00 2003-11-22
  * @author G.Clemente DEI UNIPD
  * @author M.Moro DEI UNIPD
  */

public class TorreDiControlloMdh extends TorreDiControllo {
  // non potendo estendere Monitor, ne dichiara una istanza e i necessari Condition
  private Monitor tower = new Monitor();
  private Monitor.Condition accA = tower.new Condition();   // accesso A
  private Monitor.Condition accB = tower.new Condition();   // accesso B
  private Monitor.Condition attAt = tower.new Condition();  // coda di atterraggio
      
  public void richAutorizAtterraggio(int io) {
    tower.mEnter();
    riAutAt++;                 // segnala la volont� di atterrare
    System.out.println("$$ L'aereo A"+io+" !!!!!!!! RICHIESTA AUTORIZZAZIONE ATTERRAGGIO");
    stampaSituazioneAeroporto();
    if (occupateA+occupateB != 0)
        attAt.cWait();        // pista occupata, attende
    riAutAt--;                // la pista e` completamente libera
    occupateA=1; att=true;    // la pista ora � riservata
    System.out.println("$$$$ L'aereo A"+io+" IN FASE DI ATTERRAGGIO ");
    stampaSituazioneAeroporto();
    tower.mExit();
  }

  public void freniAttivati(int io) {
    tower.mEnter();
    occupateA=0; occupateB=1;
      // per ragioni di sicurezza, pur passando in B
      // mantiene bloccata la pista con att=true
    System.out.println("$$$$$$ L'aereo A"+io+" TOCCA TERRA, FRENA ");
    stampaSituazioneAeroporto();
    tower.mExit();
  }

  public void inParcheggio(int io) {
    tower.mEnter();
    occupateB=0; att = false;     // libera la pista
    contaAtt++;
    System.out.println("$$$$$$$$ L'aereo A"+io+" LIBERA LA PISTA E PARCHEGGIA");
    stampaSituazioneAeroporto();
    if(riAutAt>=1)
      attAt.cSignal();      // libera un altro aereo che atterra
    else if (riAccPi >= 2) {
      // nessun atterraggio in vista libera 2 aerei in decollo
      accA.cSignal(); accA.cSignal();
    }
    else if (riAccPi >= 1)
      // nessun atterraggio in vista libera 1 aereo in decollo
      accA.cSignal();
    tower.mExit();
  }

  public void richAccessoPista(int io) {
    tower.mEnter();
    riAccPi++;               // segnala la volont� di decollare
    System.out.println("** L'aereo D"+io+" ^^^^^^^^ RICHIESTA PISTA PER DECOLLO");
    stampaSituazioneAeroporto();
    if (riAutAt != 0 || att || occupateA >= 2) 
        accA.cWait();        // atterraggio (in vista) o pista occupata attende
    riAccPi--; occupateA++;  // una zona A libera, la occupa
    System.out.println("**** L'aereo D"+io+ " SI PREPARA AL DECOLLO");
    stampaSituazioneAeroporto();
    tower.mExit();
  }

  public void richAutorizDecollo(int io) {
    tower.mEnter();
    riAutDe++;             // segnala la volont� di decollare
    System.out.println("****** L'aereo D"+io+" RICHIEDE AUTORIZZAZIONE DECOLLO");
    stampaSituazioneAeroporto();
    // deve entrare in zona B
    if(occupateB >= 2)
      accB.cWait();        // zona B occupata, deve attendere
    occupateA--; occupateB++;    // zona B libera - libera zona A e occupa zona B
    riAutDe--;
    System.out.println("******** L'aereo D"+io+" IN FASE DI DECOLLO ");
    stampaSituazioneAeroporto();
    if (riAutAt==0 && riAccPi>=1)
      // nessun atterraggio in vista libera 1 aereo in decollo
      accA.cSignal();
    tower.mExit();
  }

  public void inVolo(int io) {
    tower.mEnter();
    occupateB--;                // libera zona B
    contaDec++;
    System.out.println("********** L'aereo D"+io+ " HA PRESO IL VOLO!!!!! ");
    stampaSituazioneAeroporto();
    if (riAutDe>=1)
      // c'e` un decollo da autorizzare libera zona A e occupa zona B
      accB.cSignal();
    else if (riAutAt>=1 && occupateA+occupateB==0)
      // atterraggio in vista, pista libera autorizza atterraggio
      attAt.cSignal();
    tower.mExit();
  }

} //{c} TorreDiControlloMdh
