package aeroporto;
import os.*;

public class AereoCheAtterra extends Thread
{
  private int io ;
  private TorreDiControllo tc;

  public AereoCheAtterra(int io , TorreDiControllo tc)
  {
      this.io=io;
      this.tc=tc;
  }
  
  public void run()
  {
      Util.rsleep(5000, 8000);		// in volo
      tc.richAutorizAtterraggio(io);
      Util.rsleep(1000, 4000);		// si allinea con la pista
      tc.freniAttivati(io);           //esce dalla zona A ed entra in B
      Util.rsleep(1000, 4000);		// rulla sino all'uscita
      tc.inParcheggio(io);			// libera la pista
  }
}
